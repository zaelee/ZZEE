# 출처와 변경 고지 · 2026-11-24

- Archify 3.2.0: https://github.com/tt-a1i/archify · Apache-2.0. 포함된 LICENSE/NOTICE/THIRD_PARTY_NOTICES와 하위 라이선스를 보존했습니다.
- Hallmark 2.0.0: 로컬 설치 스냅샷의 MIT LICENSE를 보존했습니다. 소스 안의 제3자 고지도 유지합니다. Codex 스킬 형식 검사에 맞춰 version과 argument-hint를 metadata 아래로 옮겼습니다.
- Impeccable launcher 0.1.25: https://github.com/pbakaus/impeccable · Apache-2.0. 별도 엔진 바이너리는 포함하지 않습니다.
- Taste Skill: https://github.com/Leonxlnx/taste-skill · MIT. 로컬 design-taste-frontend 스냅샷에 공식 저장소 LICENSE를 함께 제공합니다.
- REA: https://github.com/morluto/rea · MIT. 로컬 스킬의 Windows 고정 실행 경로를 휴대 가능한 안내로 교체했습니다. 실행 엔진은 포함하지 않습니다.
- Karpathy 지침: 기존 짧은 지침의 출처 링크와 MIT 표기를 유지합니다.
- 나머지 맞춤 지침은 기존 작업 원칙에서 공개 가능한 부분을 선별·정리한 이식판입니다. 새 제3자 자산의 이용 권리를 부여하는 문서가 아닙니다.

이 패키지는 계정이나 서비스의 공식 백업이 아닙니다. 스킬 파일과 런타임·인증의 이전 범위를 구분합니다.

2026-11-24 이식 수정: 복원기의 기본 패키지 경로 처리를 보완하고 문서의 실행 명령을 회귀 검사에 추가했습니다. Impeccable의 Windows 실행 안내는 실제 SKILL.md 폴더의 절대 경로를 사용하도록 명확히 했습니다. 기존 라이선스는 유지합니다.
