[CmdletBinding()]
param(
    [string]$PackageRoot = $PSScriptRoot,
    [string]$CodexHome,
    [string]$AgentsHome,
    [switch]$Apply
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)

if (-not $CodexHome) {
    $CodexHome = if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path $env:USERPROFILE '.codex' }
}
if (-not $AgentsHome) { $AgentsHome = Join-Path $env:USERPROFILE '.agents' }

$migrationDate = '2026-11-23'
$beginMarker = '<!-- ZAE_MIGRATION:BEGIN -->'
$endMarker = '<!-- ZAE_MIGRATION:END -->'
$counts = [ordered]@{
    conflicts            = 0
    skillsPlanned       = 0
    skillsInstalled     = 0
    skillsUnchanged     = 0
    skillsConflicted    = 0
    referencesPlanned   = 0
    referencesCopied    = 0
    referencesUnchanged = 0
    referencesConflicted = 0
    agentsPlanned       = 0
    agentsUpdated       = 0
}
$conflicts = New-Object 'System.Collections.Generic.List[string]'
$backupPath = $null

function Write-Result {
    param([string]$Status, [int]$ExitCode, [string]$ErrorMessage)
    $script:counts.conflicts = $script:conflicts.Count
    $result = [ordered]@{
        status = $Status
        counts = $script:counts
        conflicts = @($script:conflicts)
        backupPath = $script:backupPath
    }
    if ($ErrorMessage) { $result.error = $ErrorMessage }
    $result | ConvertTo-Json -Depth 6 -Compress
    exit $ExitCode
}

function Get-FullPath {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { throw 'A required path is empty.' }
    [IO.Path]::GetFullPath($Path)
}

function Assert-ContainedPath {
    param([string]$Root, [string]$Candidate, [string]$Description)
    $rootFull = (Get-FullPath $Root).TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
    $candidateFull = Get-FullPath $Candidate
    $prefix = $rootFull + [IO.Path]::DirectorySeparatorChar
    if (-not $candidateFull.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw "$Description escapes its allowed root."
    }
    $candidateFull
}

function Assert-NoReparsePath {
    param([string]$Path, [string]$Description)
    $full = Get-FullPath $Path
    $root = [IO.Path]::GetPathRoot($full)
    $current = $root
    $tail = $full.Substring($root.Length)
    foreach ($part in $tail.Split(@([IO.Path]::DirectorySeparatorChar), [StringSplitOptions]::RemoveEmptyEntries)) {
        $current = Join-Path $current $part
        if (Test-Path -LiteralPath $current) {
            $item = Get-Item -Force -LiteralPath $current
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw "$Description contains a reparse point: $current"
            }
        }
    }
}

function Test-RegularDirectoryOrMissing {
    param([string]$Path, [string]$Description)
    Assert-NoReparsePath -Path $Path -Description $Description
    $full = Get-FullPath $Path
    $root = [IO.Path]::GetPathRoot($full)
    $current = $root
    foreach ($part in $full.Substring($root.Length).Split(@([IO.Path]::DirectorySeparatorChar), [StringSplitOptions]::RemoveEmptyEntries)) {
        $current = Join-Path $current $part
        if ((Test-Path -LiteralPath $current) -and -not (Test-Path -LiteralPath $current -PathType Container)) {
            throw "$Description has a non-directory path component: $current"
        }
    }
}

function Get-Sha256 {
    param([string]$Path)
    $stream = $null
    $sha256 = $null
    try {
        $sha256 = [Security.Cryptography.SHA256]::Create()
        $stream = [IO.File]::OpenRead($Path)
        ([BitConverter]::ToString($sha256.ComputeHash($stream))).Replace('-', '')
    } finally {
        if ($stream) { $stream.Dispose() }
        if ($sha256) { $sha256.Dispose() }
    }
}

function Test-SameFile {
    param([string]$Source, [string]$Destination)
    if (-not (Test-Path -LiteralPath $Destination -PathType Leaf)) { return $false }
    Assert-NoReparsePath -Path $Destination -Description 'Destination file'
    $sourceItem = Get-Item -LiteralPath $Source
    $destinationItem = Get-Item -LiteralPath $Destination
    if ($sourceItem.Length -ne $destinationItem.Length) { return $false }
    (Get-Sha256 $Source) -eq (Get-Sha256 $Destination)
}

try {
    $PackageRoot = Get-FullPath $PackageRoot
    $CodexHome = Get-FullPath $CodexHome
    $AgentsHome = Get-FullPath $AgentsHome
    Test-RegularDirectoryOrMissing -Path $PackageRoot -Description 'PackageRoot'
    if (-not (Test-Path -LiteralPath $PackageRoot -PathType Container)) { throw "PackageRoot does not exist: $PackageRoot" }
    Test-RegularDirectoryOrMissing -Path $CodexHome -Description 'CodexHome'
    Test-RegularDirectoryOrMissing -Path $AgentsHome -Description 'AgentsHome'

    $manifestPath = Assert-ContainedPath -Root $PackageRoot -Candidate (Join-Path $PackageRoot 'manifest.json') -Description 'Manifest'
    Assert-NoReparsePath -Path $manifestPath -Description 'Manifest'
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) { throw 'manifest.json is missing beside the installer package root.' }
    $manifest = [IO.File]::ReadAllText($manifestPath) | ConvertFrom-Json
    if ([string]$manifest.schemaVersion -ne '1') { throw 'manifest.json schemaVersion must be 1.' }
    if ([string]$manifest.date -ne $migrationDate) { throw "manifest.json date must be $migrationDate." }
    if ($null -eq $manifest.files) { throw 'manifest.json files is required.' }

    $validated = New-Object 'System.Collections.Generic.List[object]'
    $seenPaths = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    $invalidNameChars = [IO.Path]::GetInvalidFileNameChars()
    foreach ($entry in @($manifest.files)) {
        $relative = [string]$entry.path
        if ([string]::IsNullOrWhiteSpace($relative) -or [IO.Path]::IsPathRooted($relative) -or $relative.Contains('\')) {
            throw "Unsafe manifest path: $relative"
        }
        $parts = @($relative.Split('/'))
        if ($parts.Count -lt 2 -or $parts[0] -notin @('skills', 'memory', 'settings', 'docs')) {
            throw "Manifest path is outside an allowed payload root: $relative"
        }
        foreach ($part in $parts) {
            $reservedName = $part -match '^(?i:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?$'
            if ([string]::IsNullOrWhiteSpace($part) -or $part -eq '.' -or $part -eq '..' -or
                $part.EndsWith('.') -or $part.EndsWith(' ') -or $reservedName -or $part.IndexOfAny($invalidNameChars) -ge 0) {
                throw "Unsafe manifest path: $relative"
            }
        }
        if ($parts[0] -eq 'skills' -and $parts.Count -lt 3) { throw "Skill payload path lacks a file: $relative" }
        if (-not $seenPaths.Add($relative)) { throw "Duplicate manifest path: $relative" }

        $expectedHash = [string]$entry.sha256
        if ($expectedHash -notmatch '^[0-9A-Fa-f]{64}$') { throw "Invalid SHA256 for $relative" }
        $expectedSize = 0L
        if ([string]$entry.size -notmatch '^\d+$' -or -not [long]::TryParse([string]$entry.size, [ref]$expectedSize)) {
            throw "Invalid size for $relative"
        }

        $nativeRelative = $relative.Replace('/', [IO.Path]::DirectorySeparatorChar)
        $source = Assert-ContainedPath -Root $PackageRoot -Candidate (Join-Path $PackageRoot $nativeRelative) -Description "Payload $relative"
        Assert-NoReparsePath -Path $source -Description "Payload $relative"
        if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Payload file is missing: $relative" }
        $sourceItem = Get-Item -LiteralPath $source
        if ($sourceItem.Length -ne $expectedSize) { throw "Size mismatch for $relative" }
        if ((Get-Sha256 $source) -ne $expectedHash.ToUpperInvariant()) { throw "SHA256 mismatch for $relative" }

        $skillName = $null
        $skillRelative = $null
        if ($parts[0] -eq 'skills') {
            $skillName = $parts[1]
            $skillRelative = ($parts[2..($parts.Count - 1)] -join [IO.Path]::DirectorySeparatorChar)
        }
        $validated.Add([pscustomobject]@{
            Path = $relative
            Source = $source
            Root = $parts[0]
            SkillName = $skillName
            SkillRelative = $skillRelative
            Sha256 = $expectedHash.ToUpperInvariant()
            Size = $expectedSize
        })
    }

    $portableEntry = @($validated | Where-Object { $_.Path -eq 'memory/AGENTS.portable.md' })
    if ($portableEntry.Count -ne 1) { throw 'The manifest must contain memory/AGENTS.portable.md exactly once.' }
    $portableText = [IO.File]::ReadAllText($portableEntry[0].Source)
    if ($portableText.Contains($beginMarker) -or $portableText.Contains($endMarker)) {
        throw 'AGENTS.portable.md must not contain migration block markers.'
    }

    $codexSkillsRoot = Assert-ContainedPath -Root $CodexHome -Candidate (Join-Path $CodexHome 'skills') -Description 'Codex skills root'
    $agentsSkillsRoot = Assert-ContainedPath -Root $AgentsHome -Candidate (Join-Path $AgentsHome 'skills') -Description 'Shared skills root'
    Test-RegularDirectoryOrMissing -Path $codexSkillsRoot -Description 'Codex skills root'
    Test-RegularDirectoryOrMissing -Path $agentsSkillsRoot -Description 'Shared skills root'

    $skillPlans = New-Object 'System.Collections.Generic.List[object]'
    foreach ($group in @($validated | Where-Object { $_.Root -eq 'skills' } | Group-Object SkillName)) {
        $codexSkill = Assert-ContainedPath -Root $codexSkillsRoot -Candidate (Join-Path $codexSkillsRoot $group.Name) -Description "Codex skill $($group.Name)"
        $sharedSkill = Assert-ContainedPath -Root $agentsSkillsRoot -Candidate (Join-Path $agentsSkillsRoot $group.Name) -Description "Shared skill $($group.Name)"
        Assert-NoReparsePath -Path $codexSkill -Description "Codex skill $($group.Name)"
        Assert-NoReparsePath -Path $sharedSkill -Description "Shared skill $($group.Name)"
        $existing = @()
        foreach ($candidate in @($codexSkill, $sharedSkill)) {
            if (Test-Path -LiteralPath $candidate) {
                if (-not (Test-Path -LiteralPath $candidate -PathType Container)) {
                    $existing += $candidate
                    continue
                }
                $existing += $candidate
            }
        }

        $divergent = $false
        foreach ($folder in $existing) {
            if (-not (Test-Path -LiteralPath $folder -PathType Container)) { $divergent = $true; continue }
            foreach ($file in $group.Group) {
                $target = Assert-ContainedPath -Root $folder -Candidate (Join-Path $folder $file.SkillRelative) -Description "Existing skill file $($file.Path)"
                if (-not (Test-SameFile -Source $file.Source -Destination $target)) { $divergent = $true }
            }
        }

        if ($divergent) {
            $counts.skillsConflicted++
            $conflicts.Add("skill:$($group.Name):existing copy differs or is incomplete")
            $action = 'conflict'
        } elseif ($existing.Count -gt 0) {
            $counts.skillsUnchanged++
            $action = 'unchanged'
        } else {
            $counts.skillsPlanned++
            $action = 'install'
        }
        $skillPlans.Add([pscustomobject]@{ Name = $group.Name; Files = @($group.Group); Destination = $codexSkill; Action = $action })
    }

    $migrationRoot = Assert-ContainedPath -Root $CodexHome -Candidate (Join-Path $CodexHome "migrations\$migrationDate") -Description 'Migration reference root'
    Test-RegularDirectoryOrMissing -Path $migrationRoot -Description 'Migration reference root'
    $backupRoot = Assert-ContainedPath -Root $migrationRoot -Candidate (Join-Path $migrationRoot 'backups') -Description 'Backup root'
    Test-RegularDirectoryOrMissing -Path $backupRoot -Description 'Backup root'
    $stagingRoot = Assert-ContainedPath -Root $migrationRoot -Candidate (Join-Path $migrationRoot 'staging') -Description 'Skill staging root'
    Test-RegularDirectoryOrMissing -Path $stagingRoot -Description 'Skill staging root'
    $referencePlans = New-Object 'System.Collections.Generic.List[object]'
    foreach ($entry in @($validated | Where-Object { $_.Root -ne 'skills' })) {
        $destination = Assert-ContainedPath -Root $migrationRoot -Candidate (Join-Path $migrationRoot ($entry.Path.Replace('/', [IO.Path]::DirectorySeparatorChar))) -Description "Reference $($entry.Path)"
        Assert-NoReparsePath -Path $destination -Description "Reference $($entry.Path)"
        Test-RegularDirectoryOrMissing -Path (Split-Path -Parent $destination) -Description "Reference parent $($entry.Path)"
        if ((Test-Path -LiteralPath $destination) -and -not (Test-Path -LiteralPath $destination -PathType Leaf)) {
            $conflicts.Add("reference:$($entry.Path):destination is not a file")
            $counts.referencesConflicted++
            $referencePlans.Add([pscustomobject]@{ Entry = $entry; Destination = $destination; Action = 'conflict' })
        } elseif (Test-SameFile -Source $entry.Source -Destination $destination) {
            $counts.referencesUnchanged++
            $referencePlans.Add([pscustomobject]@{ Entry = $entry; Destination = $destination; Action = 'unchanged' })
        } elseif (Test-Path -LiteralPath $destination) {
            $conflicts.Add("reference:$($entry.Path):existing reference differs")
            $counts.referencesConflicted++
            $referencePlans.Add([pscustomobject]@{ Entry = $entry; Destination = $destination; Action = 'conflict' })
        } else {
            $counts.referencesPlanned++
            $referencePlans.Add([pscustomobject]@{ Entry = $entry; Destination = $destination; Action = 'copy' })
        }
    }

    $agentsPath = Assert-ContainedPath -Root $CodexHome -Candidate (Join-Path $CodexHome 'AGENTS.md') -Description 'AGENTS.md'
    Assert-NoReparsePath -Path $agentsPath -Description 'AGENTS.md'
    $agentsAction = 'unchanged'
    $desiredAgentsText = $null
    $existingAgentsText = ''
    $agentsExisted = $false
    $agentsOriginalLength = $null
    $agentsOriginalHash = $null
    if ((Test-Path -LiteralPath $agentsPath) -and -not (Test-Path -LiteralPath $agentsPath -PathType Leaf)) {
        $conflicts.Add('agents:AGENTS.md destination is not a file')
        $agentsAction = 'conflict'
    } else {
        if (Test-Path -LiteralPath $agentsPath -PathType Leaf) {
            $agentsExisted = $true
            $agentsItem = Get-Item -LiteralPath $agentsPath
            $agentsOriginalLength = $agentsItem.Length
            $agentsOriginalHash = Get-Sha256 $agentsPath
            $existingAgentsText = [IO.File]::ReadAllText($agentsPath)
        }
        $beginMatches = [regex]::Matches($existingAgentsText, [regex]::Escape($beginMarker)).Count
        $endMatches = [regex]::Matches($existingAgentsText, [regex]::Escape($endMarker)).Count
        $beginPosition = $existingAgentsText.IndexOf($beginMarker, [StringComparison]::Ordinal)
        $endPosition = $existingAgentsText.IndexOf($endMarker, [StringComparison]::Ordinal)
        if ($beginMatches -ne $endMatches -or $beginMatches -gt 1 -or
            ($beginMatches -eq 1 -and $endPosition -lt $beginPosition)) {
            $conflicts.Add('agents:AGENTS.md has malformed migration markers')
            $agentsAction = 'conflict'
        } else {
            $portableBody = $portableText.TrimEnd("`r", "`n")
            $block = "$beginMarker`r`n$portableBody`r`n$endMarker"
            if ($beginMatches -eq 1) {
                $end = $endPosition + $endMarker.Length
                $desiredAgentsText = $existingAgentsText.Substring(0, $beginPosition) + $block + $existingAgentsText.Substring($end)
            } elseif ($existingAgentsText.Length -eq 0) {
                $desiredAgentsText = "$block`r`n"
            } else {
                $desiredAgentsText = $existingAgentsText.TrimEnd("`r", "`n") + "`r`n`r`n$block`r`n"
            }
            if ($desiredAgentsText -ne $existingAgentsText) {
                $agentsAction = 'update'
                $counts.agentsPlanned = 1
            }
        }
    }

    $configPath = Assert-ContainedPath -Root $CodexHome -Candidate (Join-Path $CodexHome 'config.toml') -Description 'config.toml'
    Assert-NoReparsePath -Path $configPath -Description 'config.toml'
    if ((Test-Path -LiteralPath $configPath) -and -not (Test-Path -LiteralPath $configPath -PathType Leaf)) {
        throw 'config.toml exists but is not a regular file.'
    }
} catch {
    Write-Result -Status 'integrity_error' -ExitCode 2 -ErrorMessage $_.Exception.Message
}

if (-not $Apply) {
    $previewStatus = if ($conflicts.Count -gt 0) { 'preview_with_conflicts' } else { 'preview' }
    Write-Result -Status $previewStatus -ExitCode 0 -ErrorMessage $null
}

try {
    $needsConfigBackup = Test-Path -LiteralPath $configPath -PathType Leaf
    $needsAgentsBackup = $agentsAction -eq 'update' -and $agentsExisted
    if ($needsConfigBackup -or $needsAgentsBackup) {
        $backupPath = Assert-ContainedPath -Root $backupRoot -Candidate (Join-Path $backupRoot ((Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssfffZ') + '-' + [Guid]::NewGuid().ToString('N').Substring(0, 8))) -Description 'Backup path'
        New-Item -ItemType Directory -Force -Path $backupPath | Out-Null
        if ($needsConfigBackup) { Copy-Item -LiteralPath $configPath -Destination (Join-Path $backupPath 'config.toml') }
    }

    foreach ($plan in $skillPlans) {
        if ($plan.Action -ne 'install') { continue }
        if (-not (Test-Path -LiteralPath $codexSkillsRoot)) { New-Item -ItemType Directory -Force -Path $codexSkillsRoot | Out-Null }
        if (-not (Test-Path -LiteralPath $stagingRoot)) { New-Item -ItemType Directory -Force -Path $stagingRoot | Out-Null }
        $stagePath = Assert-ContainedPath -Root $stagingRoot -Candidate (Join-Path $stagingRoot ('skill-' + [Guid]::NewGuid().ToString('N'))) -Description "Staged skill $($plan.Name)"
        New-Item -ItemType Directory -Path $stagePath | Out-Null
        foreach ($file in $plan.Files) {
            $stagedFile = Assert-ContainedPath -Root $stagePath -Candidate (Join-Path $stagePath $file.SkillRelative) -Description "Staged file $($file.Path)"
            $parent = Split-Path -Parent $stagedFile
            if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
            Copy-Item -LiteralPath $file.Source -Destination $stagedFile
            $stagedItem = Get-Item -LiteralPath $stagedFile
            if ($stagedItem.Length -ne $file.Size -or (Get-Sha256 $stagedFile) -ne $file.Sha256) {
                throw "Staged skill verification failed for $($file.Path)"
            }
        }
        Assert-NoReparsePath -Path $plan.Destination -Description "Final skill $($plan.Name)"
        if (Test-Path -LiteralPath $plan.Destination) { throw "Final skill appeared after preflight: $($plan.Name)" }
        [IO.Directory]::Move($stagePath, $plan.Destination)
        $counts.skillsInstalled++
    }

    foreach ($plan in $referencePlans) {
        if ($plan.Action -ne 'copy') { continue }
        $parent = Split-Path -Parent $plan.Destination
        if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
        $leafName = [IO.Path]::GetFileName($plan.Destination)
        $referenceTempPath = Assert-ContainedPath -Root $parent -Candidate (Join-Path $parent ('.' + $leafName + '.migration-' + [Guid]::NewGuid().ToString('N') + '.tmp')) -Description "Reference temporary file $($plan.Entry.Path)"
        $ownsReferenceTemp = $false
        try {
            $sourceStream = $null
            $tempStream = $null
            try {
                $tempStream = [IO.File]::Open($referenceTempPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
                $ownsReferenceTemp = $true
                $sourceStream = [IO.File]::Open($plan.Entry.Source, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
                $sourceStream.CopyTo($tempStream)
                $tempStream.Flush($true)
            } finally {
                if ($sourceStream) { $sourceStream.Dispose() }
                if ($tempStream) { $tempStream.Dispose() }
            }
            $tempItem = Get-Item -LiteralPath $referenceTempPath
            if ($tempItem.Length -ne $plan.Entry.Size -or (Get-Sha256 $referenceTempPath) -ne $plan.Entry.Sha256) {
                throw "Reference temporary file verification failed for $($plan.Entry.Path)"
            }
            if (Test-Path -LiteralPath $plan.Destination) {
                Remove-Item -LiteralPath $referenceTempPath -Force
                $conflicts.Add("reference:$($plan.Entry.Path):destination appeared after preflight")
                $counts.referencesConflicted++
                continue
            }
            [IO.File]::Move($referenceTempPath, $plan.Destination)
            $counts.referencesCopied++
        } catch {
            if ($ownsReferenceTemp -and $referenceTempPath -and (Test-Path -LiteralPath $referenceTempPath -PathType Leaf)) {
                Remove-Item -LiteralPath $referenceTempPath -Force
            }
            if (Test-Path -LiteralPath $plan.Destination) {
                $conflicts.Add("reference:$($plan.Entry.Path):destination appeared during publish")
                $counts.referencesConflicted++
                continue
            }
            throw
        }
    }

    if ($agentsAction -eq 'update') {
        if (-not (Test-Path -LiteralPath $CodexHome)) { New-Item -ItemType Directory -Force -Path $CodexHome | Out-Null }
        $agentsTempPath = Assert-ContainedPath -Root $CodexHome -Candidate (Join-Path $CodexHome ('.AGENTS.md.migration-' + [Guid]::NewGuid().ToString('N') + '.tmp')) -Description 'AGENTS temporary file'
        $ownsAgentsTemp = $false
        try {
            $utf8 = New-Object Text.UTF8Encoding($false)
            $expectedBytes = $utf8.GetBytes($desiredAgentsText)
            $agentsTempStream = $null
            try {
                $agentsTempStream = [IO.File]::Open($agentsTempPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
                $ownsAgentsTemp = $true
                $agentsTempStream.Write($expectedBytes, 0, $expectedBytes.Length)
                $agentsTempStream.Flush($true)
            } finally {
                if ($agentsTempStream) { $agentsTempStream.Dispose() }
            }
            $tempItem = Get-Item -LiteralPath $agentsTempPath
            if ($tempItem.Length -ne $expectedBytes.Length -or [IO.File]::ReadAllText($agentsTempPath, $utf8) -ne $desiredAgentsText) {
                throw 'AGENTS temporary file verification failed.'
            }

            if ($agentsExisted) {
                Assert-NoReparsePath -Path $agentsPath -Description 'AGENTS.md'
                if (-not (Test-Path -LiteralPath $agentsPath -PathType Leaf)) { throw 'AGENTS.md disappeared after preflight.' }
                $currentAgentsItem = Get-Item -LiteralPath $agentsPath
                if ($currentAgentsItem.Length -ne $agentsOriginalLength -or (Get-Sha256 $agentsPath) -ne $agentsOriginalHash) {
                    throw 'AGENTS.md changed after preflight; refusing to replace it.'
                }
                $agentsBackupFile = Join-Path $backupPath 'AGENTS.md'
                [IO.File]::Replace($agentsTempPath, $agentsPath, $agentsBackupFile)
            } else {
                if (Test-Path -LiteralPath $agentsPath) { throw 'AGENTS.md appeared after preflight; refusing to replace it.' }
                [IO.File]::Move($agentsTempPath, $agentsPath)
            }
            if ([IO.File]::ReadAllText($agentsPath, $utf8) -ne $desiredAgentsText) { throw 'AGENTS.md verification failed after atomic publish.' }
        } catch {
            if ($ownsAgentsTemp -and $agentsTempPath -and (Test-Path -LiteralPath $agentsTempPath -PathType Leaf)) {
                Remove-Item -LiteralPath $agentsTempPath -Force
            }
            throw
        }
        $counts.agentsUpdated = 1
    }
} catch {
    Write-Result -Status 'apply_error' -ExitCode 3 -ErrorMessage $_.Exception.Message
}

$status = if ($conflicts.Count -gt 0) { 'applied_with_conflicts' } else { 'applied' }
Write-Result -Status $status -ExitCode 0 -ErrorMessage $null
