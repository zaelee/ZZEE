---
name: agy-subagent
description: "Prepare bounded code exploration, log summaries and review briefs for the paired-workbench Antigravity runner."
---

# Antigravity 조사·검토 · 공개 이식판

원본의 큰 저장소·로그 위임 목적을 유지하되, 현재 폴더 전체를 외부 CLI에 넘기는 이전 래퍼는 이식하지 않습니다. 실제 실행은 함께 설치한 paired-workbench의 scripts/dispatch.py 한 경로를 사용합니다.

- scout: 승인된 코드 발췌와 구체적인 질문에서 관련 심볼·근거·누락된 자료를 정리합니다.
- qa: 승인된 변경 발췌와 검증 조건으로 오류·회귀 후보를 검토합니다.
- 긴 테스트 로그는 먼저 로컬에서 관련 실패 구간만 추립니다. 계정값·회사 원문·개인 경로를 제거한 뒤 전달 허용 범위를 확인합니다.
- 실행 파일·결과 디렉터리는 현재 PC에서 확인합니다. 같은 작업을 paired-workbench와 별도 에이전트로 중복 요청하지 않습니다.
- 결과를 원본과 대조하고 실제 수정·검증은 Codex가 맡습니다. 도구가 없으면 설치되었다고 가정하지 않습니다.
