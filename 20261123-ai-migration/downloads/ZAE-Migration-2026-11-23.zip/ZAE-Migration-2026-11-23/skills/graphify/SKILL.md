---
name: graphify
description: "Use an existing graphify graph for relationship questions or prepare an explicitly requested graph build with the installed graphifyy tool."
---

# Graphify · 이식용 연결 가이드

이 파일은 기존 Graphify 업무 범위를 옮기는 짧은 연결 지침입니다. 전체 upstream 워크플로와 Python 런타임은 포함하지 않습니다.

단순 파일 조회에는 일반 검색을 사용합니다. 명시적인 그래프 생성·갱신 요청이나 기존 그래프로 해결할 관계 질문에 적용합니다. 기존 graphify-out 자료와 원본을 읽어 사실·추론·미확인을 구분하고 근거를 남깁니다.

실제 생성 요청 시 설치된 graphify 명령과 버전을 확인하고 그 버전의 도움말과 공식 배포 지침을 읽습니다. 기록된 원본 PC 버전은 graphifyy 0.9.31이며 다른 PC를 강제로 다운그레이드하지 않습니다. 설치가 필요하면 사용 가능한 공식 배포판과 요구 환경을 확인한 뒤 요청 범위에서 진행합니다.

- 패키지 출처: https://pypi.org/project/graphifyy/
- 가상환경·API 키·graphify-out 결과·개인 프로젝트 원문은 이 패키지에 없습니다.
- 빌드 시 이전 그래프를 보존하고 실패 구간·빈 결과·항목 감소를 확인합니다. 성공 여부를 실제 출력으로 검증합니다.
