# 이식판 실행 안내

Python과 Google Antigravity CLI(agy)가 대상 PC에서 준비돼 있어야 합니다. 앱 설치·로그인은 이 패키지가 수행하지 않습니다.

1. Get-Command python, agy 로 실행 파일을 확인합니다.
2. 공개 또는 외부 제공자 전달까지 승인된 입력만 UTF-8 brief.txt로 만듭니다. 전체 프로젝트·회사 문서·인증값을 묶어 보내지 않습니다.
3. 설치된 paired-workbench/scripts/dispatch.py를 실행합니다. --brief에는 준비한 입력, --result-dir에는 현재 작업 폴더 아래 결과 디렉터리, --output에는 저장할 결과 파일을 지정합니다. 역할은 copy/scout/qa입니다.
4. 출력된 작업 ID와 완료 상태, 전체 결과 파일을 확인합니다. incomplete 또는 unavailable은 완료가 아닙니다. 동일 조건의 자동 재시도를 하지 않습니다.
5. 필요할 때만 반환된 정확한 대화 ID로 이어갑니다. 사용자 설정을 바꾸거나 유료 추가 할당량을 켜지 않습니다.

브라우저는 Aside의 현재 guide와 help를 기준으로 동작합니다. 웹에 표시된 개인정보를 다른 제공자에게 전달할 권한까지 있다고 가정하지 않습니다.
