---
name: antigravity-aside-router
description: "Choose bounded Antigravity text delegation or Aside browser work for the user-requested task."
---

# 작업 분담 · 공개 이식판

설치된 도구와 사용자의 명시적 선택을 기준으로 맡깁니다. 새 컴퓨터의 앱 로그인·연결 상태는 별도로 확인합니다.

- 공개 자료 또는 외부 전달까지 승인된 텍스트의 초안·요약·분류는 Antigravity를 활용합니다. 민감한 회사 원문·계정·전체 채팅을 자동 전달하지 않습니다.
- 웹페이지·로그인 상태·DOM·화면 검수가 필요한 단계는 Aside를 사용합니다. 충분한 서비스 연결 도구는 우선 사용할 수 있습니다.
- 정확한 파일 편집·검증·최종 반영은 Codex가 수행합니다. 한 줄 변경이나 단순 계산에 별도 위임을 만들지 않습니다.
- Antigravity는 함께 제공한 paired-workbench 실행기를 사용하며, 같은 결과물을 여러 엔진에서 중복 생성하지 않습니다. 시작과 완료 시 실제 맡긴 범위를 알립니다.
- 모델·사용량·추가 과금·보안 설정을 유지합니다. 도구가 없거나 차단되면 연결 완료로 말하지 말고 독립적으로 가능한 일을 진행합니다.

실제 텍스트 위임 때만 [실행 안내](references/execution.md)를 읽습니다.
