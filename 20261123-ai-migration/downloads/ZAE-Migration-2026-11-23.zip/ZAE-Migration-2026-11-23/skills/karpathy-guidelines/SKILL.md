---
name: karpathy-guidelines
description: Keep code changes focused and verifiable. Use when implementation or refactoring involves scope, design, or validation tradeoffs.
license: MIT
---

# Karpathy Guidelines

Coding guidance derived from [Andrej Karpathy's observations](https://x.com/karpathy/status/2015883857489522876).

## Completion conditions

- The requested behavior works, with relevant verification appropriate to the change.
- Changed lines serve the request; existing style and unrelated work are preserved.
- The report states the result, checks performed, and meaningful remaining uncertainty.

## Default approach

Read the affected code and choose the simplest implementation that satisfies the request. Reuse existing code and standard facilities before adding dependencies or abstractions.

State assumptions that affect the result. Ask when an answer materially changes correctness, scope, or permission; use reasonable defaults for routine choices and continue independent work while waiting.

For a bug, use a reproduction or regression check that distinguishes the broken behavior from the fix. For refactoring, check the affected behavior. Trivial edits need proportionate verification rather than a new test suite.

## Scope boundaries

Keep requested behavior, security, data integrity, and accessibility intact. Remove code made unused by your change; leave unrelated cleanup for its own task. Do not add speculative features, configuration, or abstractions.
