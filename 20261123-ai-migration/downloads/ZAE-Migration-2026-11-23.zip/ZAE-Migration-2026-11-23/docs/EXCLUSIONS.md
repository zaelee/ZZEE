# 공개판 제외 항목

- 업무 전용 artifact-template-ldsf, corporate-card-processing, overseas-card-invoices의 본문·원본 자산·회계 규칙
- 3D 참고용 제3자 이미지, 개인 장애 기록, 회사 NAS 주소·폴더 색인·업무 지식 원문
- auth.json, API 키, 쿠키, 브라우저 프로필, 개인 대화, 자동 메모리/세션 DB, 로그, 전체 원본 config.toml
- 가상환경, node_modules, 앱 실행 파일, 별도 분석 엔진, 자동화 실행 상태

개인 스킬 18개 중 15개를 공개 이식판 또는 라이선스가 보존된 스냅샷으로 제공합니다. 일부 이식판은 회사/PC 전용 세부 기능이 축약되어 있습니다. 모든 119개를 자동 설치하는 패키지는 아닙니다.
