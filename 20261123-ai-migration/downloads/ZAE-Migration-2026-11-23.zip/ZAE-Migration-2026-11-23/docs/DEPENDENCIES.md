# 실행 환경과 검증

- Windows PowerShell 5.1: 복원기 실행. 관리자 권한을 요구하지 않습니다. 조직의 실행 정책을 임의로 완화하지 않습니다.
- Node.js: Archify/Hallmark/Taste/Impeccable/REA 보조 도구를 쓸 때 해당 스킬의 버전 요구를 확인합니다. 이 패키지는 Node를 설치하지 않습니다.
- Python 3: paired-workbench 실행기와 Graphify를 쓸 때 필요합니다. Graphify 런타임은 별도 설치입니다.
- Antigravity CLI(agy)와 Aside: 각 앱 설치·계정 연결·명령 경로를 새 PC에서 확인합니다. 이식된 스킬만으로 브라우저/모델 연결이 생기지 않습니다.
- Impeccable 엔진, REA 런타임·분석 엔진, Graphify 전체 upstream 워크플로는 별도 준비 항목입니다. 내려받기/설치는 실제 해당 작업의 요청과 대상 PC 권한 안에서 수행합니다.

새 채팅에서 설치된 스킬 이름을 확인한 뒤 작은 비공개 자료 없는 예제로 각 기능을 검증하세요. 이 PC에서의 패키지·설치기 검사는 다른 PC의 앱 로그인·런타임 실행 성공을 뜻하지 않습니다.
