[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$script:Passed = 0
$script:Failed = 0
$installer = Join-Path $PSScriptRoot 'Install-Migration.ps1'
$runRoot = Join-Path $PSScriptRoot ('.test-runs\run-{0}-{1}' -f $PID, [Guid]::NewGuid().ToString('N'))

function Write-Utf8File {
    param([string]$Path, [string]$Content)
    $parent = Split-Path -Parent $Path
    if ($parent -and -not (Test-Path -LiteralPath $parent)) {
        New-Item -ItemType Directory -Force -Path $parent | Out-Null
    }
    [IO.File]::WriteAllText($Path, $Content, (New-Object Text.UTF8Encoding($false)))
}

function Get-FileSha256 {
    param([string]$Path)
    (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToUpperInvariant()
}

function New-TestPackage {
    param(
        [string]$Root,
        [switch]$BadHash,
        [string]$OverridePath,
        [int]$LargeSkillBytes = 0,
        [int]$LargeAgentsChars = 0,
        [int]$LargeReferenceBytes = 0
    )

    New-Item -ItemType Directory -Force -Path $Root | Out-Null
    $payload = [ordered]@{
        'skills/sample-skill/SKILL.md' = "# Sample skill`r`n"
        'skills/sample-skill/reference.txt' = "portable reference`r`n"
        'memory/AGENTS.portable.md' = if ($LargeAgentsChars -gt 0) { ('A' * $LargeAgentsChars) + "`r`n" } else { "Portable migration guidance.`r`n" }
        'settings/preferences.md' = "Reference only; do not activate.`r`n"
        'docs/README.md' = "Migration reference.`r`n"
    }

    $files = @()
    foreach ($relative in $payload.Keys) {
        $nativeRelative = $relative.Replace('/', [IO.Path]::DirectorySeparatorChar)
        $path = Join-Path $Root $nativeRelative
        Write-Utf8File -Path $path -Content $payload[$relative]
        $item = Get-Item -LiteralPath $path
        $manifestPath = if ($OverridePath -and $relative -eq 'docs/README.md') { $OverridePath } else { $relative }
        $hash = Get-FileSha256 -Path $path
        if ($BadHash -and $relative -eq 'docs/README.md') { $hash = ('0' * 64) }
        $files += [ordered]@{ path = $manifestPath; sha256 = $hash; size = [long]$item.Length }
    }

    if ($LargeSkillBytes -gt 0) {
        $relative = 'skills/sample-skill/bulk.bin'
        $path = Join-Path $Root ($relative.Replace('/', [IO.Path]::DirectorySeparatorChar))
        $parent = Split-Path -Parent $path
        if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
        [IO.File]::WriteAllBytes($path, (New-Object byte[] $LargeSkillBytes))
        $item = Get-Item -LiteralPath $path
        $files += [ordered]@{ path = $relative; sha256 = (Get-FileSha256 $path); size = [long]$item.Length }
    }

    if ($LargeReferenceBytes -gt 0) {
        $relative = 'docs/large.bin'
        $path = Join-Path $Root ($relative.Replace('/', [IO.Path]::DirectorySeparatorChar))
        $parent = Split-Path -Parent $path
        if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
        [IO.File]::WriteAllBytes($path, (New-Object byte[] $LargeReferenceBytes))
        $item = Get-Item -LiteralPath $path
        $files += [ordered]@{ path = $relative; sha256 = (Get-FileSha256 $path); size = [long]$item.Length }
    }

    $manifest = [ordered]@{ schemaVersion = 1; date = '2026-11-23'; files = $files }
    Write-Utf8File -Path (Join-Path $Root 'manifest.json') -Content ($manifest | ConvertTo-Json -Depth 5)
}

function Invoke-Installer {
    param(
        [string]$PackageRoot,
        [string]$CodexHome,
        [string]$AgentsHome,
        [switch]$Apply
    )

    $hostExe = (Get-Process -Id $PID).Path
    $arguments = @('-NoProfile', '-NonInteractive', '-File', $installer,
        '-PackageRoot', $PackageRoot, '-CodexHome', $CodexHome, '-AgentsHome', $AgentsHome)
    if ($Apply) { $arguments += '-Apply' }
    $output = & $hostExe @arguments 2>&1
    $exitCode = $LASTEXITCODE
    $text = ($output | Out-String).Trim()
    $json = $null
    if ($text) {
        try { $json = $text | ConvertFrom-Json } catch { }
    }
    [pscustomobject]@{ ExitCode = $exitCode; Text = $text; Json = $json }
}

function Start-InstallerProcess {
    param([string]$PackageRoot, [string]$CodexHome, [string]$AgentsHome)
    $hostExe = (Get-Process -Id $PID).Path
    $arguments = @('-NoProfile', '-NonInteractive', '-File', $installer, '-PackageRoot', $PackageRoot,
        '-CodexHome', $CodexHome, '-AgentsHome', $AgentsHome, '-Apply')
    $quoted = foreach ($argument in $arguments) { '"' + $argument.Replace('"', '\"') + '"' }
    $info = New-Object Diagnostics.ProcessStartInfo
    $info.FileName = $hostExe
    $info.Arguments = $quoted -join ' '
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    [Diagnostics.Process]::Start($info)
}

function Assert-True {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw $Message }
}

function Assert-Equal {
    param($Expected, $Actual, [string]$Message)
    if ($Expected -ne $Actual) {
        throw "$Message (expected '$Expected', actual '$Actual')"
    }
}

function Invoke-Test {
    param([string]$Name, [scriptblock]$Body)
    try {
        & $Body
        $script:Passed++
        Write-Host "PASS $Name"
    } catch {
        $script:Failed++
        Write-Host "FAIL $Name`: $($_.Exception.Message)"
    }
}

function Get-TreeFingerprint {
    param([string]$Root)
    $lines = foreach ($file in (Get-ChildItem -LiteralPath $Root -File -Recurse | Sort-Object FullName)) {
        '{0}|{1}|{2}' -f $file.FullName.Substring($Root.Length), $file.Length, (Get-FileSha256 $file.FullName)
    }
    $lines -join "`n"
}

New-Item -ItemType Directory -Force -Path $runRoot | Out-Null

Invoke-Test 'preview performs no destination writes' {
    $case = Join-Path $runRoot 'preview'
    $package = Join-Path $case 'package'
    $codex = Join-Path $case 'codex'
    $agents = Join-Path $case 'agents'
    New-TestPackage -Root $package

    $result = Invoke-Installer -PackageRoot $package -CodexHome $codex -AgentsHome $agents
    Assert-Equal 0 $result.ExitCode $result.Text
    Assert-Equal 'preview' $result.Json.status 'Expected preview status'
    Assert-True (-not (Test-Path -LiteralPath $codex)) 'Preview created CodexHome'
    Assert-True (-not (Test-Path -LiteralPath $agents)) 'Preview created AgentsHome'
}

Invoke-Test 'clean apply is idempotent and preserves unrelated AGENTS content' {
    $case = Join-Path $runRoot 'clean'
    $package = Join-Path $case 'package'
    $codex = Join-Path $case 'codex'
    $agents = Join-Path $case 'agents'
    New-TestPackage -Root $package
    Write-Utf8File -Path (Join-Path $codex 'AGENTS.md') -Content "Keep this unrelated rule.`r`n"
    Write-Utf8File -Path (Join-Path $codex 'config.toml') -Content "model = 'keep-me'`r`n"

    $first = Invoke-Installer -PackageRoot $package -CodexHome $codex -AgentsHome $agents -Apply
    Assert-Equal 0 $first.ExitCode $first.Text
    Assert-Equal 'applied' $first.Json.status 'Expected applied status'
    Assert-True (Test-Path -LiteralPath (Join-Path $codex 'skills\sample-skill\SKILL.md')) 'Skill was not installed'
    Assert-True (Test-Path -LiteralPath (Join-Path $codex 'migrations\2026-11-23\docs\README.md')) 'Reference was not copied'
    $agentsText = [IO.File]::ReadAllText((Join-Path $codex 'AGENTS.md'))
    Assert-True ($agentsText.Contains('Keep this unrelated rule.')) 'Unrelated AGENTS content was lost'
    Assert-True ($agentsText.Contains('<!-- ZAE_MIGRATION:BEGIN -->')) 'Managed block was not added'
    Assert-Equal "model = 'keep-me'`r`n" ([IO.File]::ReadAllText((Join-Path $codex 'config.toml'))) 'config.toml was changed'
    Assert-True (Test-Path -LiteralPath (Join-Path ([string]$first.Json.backupPath) 'config.toml')) 'config.toml backup was not made'
    Assert-True (Test-Path -LiteralPath (Join-Path ([string]$first.Json.backupPath) 'AGENTS.md')) 'AGENTS.md backup was not made'

    $skillBefore = Get-TreeFingerprint (Join-Path $codex 'skills\sample-skill')
    $agentsBefore = Get-FileSha256 (Join-Path $codex 'AGENTS.md')
    $referenceBefore = Get-TreeFingerprint (Join-Path $codex 'migrations\2026-11-23\docs')
    $second = Invoke-Installer -PackageRoot $package -CodexHome $codex -AgentsHome $agents -Apply
    Assert-Equal 0 $second.ExitCode $second.Text
    Assert-Equal $skillBefore (Get-TreeFingerprint (Join-Path $codex 'skills\sample-skill')) 'Second apply changed skill bytes'
    Assert-Equal $agentsBefore (Get-FileSha256 (Join-Path $codex 'AGENTS.md')) 'Second apply changed AGENTS.md'
    Assert-Equal $referenceBefore (Get-TreeFingerprint (Join-Path $codex 'migrations\2026-11-23\docs')) 'Second apply changed reference bytes'
    Assert-True (Test-Path -LiteralPath (Join-Path ([string]$second.Json.backupPath) 'config.toml')) 'Second apply did not back up config.toml'
    Assert-True (-not (Test-Path -LiteralPath (Join-Path ([string]$second.Json.backupPath) 'AGENTS.md'))) 'Unchanged AGENTS.md was unnecessarily backed up'
}

Invoke-Test 'skill conflict leaves Codex and shared skill bytes unchanged' {
    $case = Join-Path $runRoot 'conflict'
    $package = Join-Path $case 'package'
    $codex = Join-Path $case 'codex'
    $agents = Join-Path $case 'agents'
    New-TestPackage -Root $package
    Write-Utf8File -Path (Join-Path $codex 'skills\sample-skill\SKILL.md') -Content "# Sample skill`r`n"
    Write-Utf8File -Path (Join-Path $codex 'skills\sample-skill\reference.txt') -Content "portable reference`r`n"
    Write-Utf8File -Path (Join-Path $agents 'skills\sample-skill\SKILL.md') -Content "# Shared divergent skill`r`n"
    Write-Utf8File -Path (Join-Path $agents 'skills\sample-skill\local.txt') -Content "retain shared bytes`r`n"
    $codexBefore = Get-TreeFingerprint (Join-Path $codex 'skills\sample-skill')
    $sharedBefore = Get-TreeFingerprint (Join-Path $agents 'skills\sample-skill')

    $result = Invoke-Installer -PackageRoot $package -CodexHome $codex -AgentsHome $agents -Apply
    Assert-Equal 0 $result.ExitCode $result.Text
    Assert-Equal 'applied_with_conflicts' $result.Json.status 'Expected conflict status'
    Assert-Equal 1 $result.Json.counts.skillsConflicted 'Expected one conflicted skill'
    Assert-Equal $codexBefore (Get-TreeFingerprint (Join-Path $codex 'skills\sample-skill')) 'Codex skill changed during conflict'
    Assert-Equal $sharedBefore (Get-TreeFingerprint (Join-Path $agents 'skills\sample-skill')) 'Shared skill changed during conflict'
}

Invoke-Test 'malformed AGENTS markers are reported without changing the file' {
    $case = Join-Path $runRoot 'malformed-agents'
    $package = Join-Path $case 'package'
    $codex = Join-Path $case 'codex'
    $agents = Join-Path $case 'agents'
    New-TestPackage -Root $package
    $agentsPath = Join-Path $codex 'AGENTS.md'
    Write-Utf8File -Path $agentsPath -Content "Keep this.`r`n<!-- ZAE_MIGRATION:END -->`r`nold`r`n<!-- ZAE_MIGRATION:BEGIN -->`r`n"
    $before = Get-FileSha256 $agentsPath

    $result = Invoke-Installer -PackageRoot $package -CodexHome $codex -AgentsHome $agents -Apply
    Assert-Equal 0 $result.ExitCode $result.Text
    Assert-Equal 'applied_with_conflicts' $result.Json.status 'Expected malformed marker conflict'
    Assert-Equal $before (Get-FileSha256 $agentsPath) 'Malformed AGENTS.md was modified'
}

Invoke-Test 'edited dated reference is a conflict and is never overwritten' {
    $case = Join-Path $runRoot 'edited-reference'
    $package = Join-Path $case 'package'
    $codex = Join-Path $case 'codex'
    $agents = Join-Path $case 'agents'
    New-TestPackage -Root $package
    $first = Invoke-Installer -PackageRoot $package -CodexHome $codex -AgentsHome $agents -Apply
    Assert-Equal 0 $first.ExitCode $first.Text
    $referencePath = Join-Path $codex 'migrations\2026-11-23\docs\README.md'
    Write-Utf8File -Path $referencePath -Content "Locally edited reference.`r`n"
    $before = Get-FileSha256 $referencePath

    $second = Invoke-Installer -PackageRoot $package -CodexHome $codex -AgentsHome $agents -Apply
    Assert-Equal 0 $second.ExitCode $second.Text
    Assert-Equal 'applied_with_conflicts' $second.Json.status 'Expected edited reference conflict'
    Assert-Equal 1 $second.Json.counts.referencesConflicted 'Expected one reference conflict'
    Assert-Equal $before (Get-FileSha256 $referencePath) 'Edited reference was overwritten'
}

Invoke-Test 'failed staged skill publish leaves no partial incoming skill discoverable' {
    $case = Join-Path $runRoot 'staged-skill-failure'
    $package = Join-Path $case 'package'
    $codex = Join-Path $case 'codex'
    $agents = Join-Path $case 'agents'
    New-TestPackage -Root $package -LargeSkillBytes (32 * 1024 * 1024)
    $process = Start-InstallerProcess -PackageRoot $package -CodexHome $codex -AgentsHome $agents
    $stagingRoot = Join-Path $codex 'migrations\2026-11-23\staging'
    $finalSkill = Join-Path $codex 'skills\sample-skill'
    $deadline = [DateTime]::UtcNow.AddSeconds(15)
    while (-not (Test-Path -LiteralPath $stagingRoot) -and -not $process.HasExited -and [DateTime]::UtcNow -lt $deadline) {
        Start-Sleep -Milliseconds 1
    }
    Assert-True (Test-Path -LiteralPath $stagingRoot) 'Installer did not use the required staging root'
    New-Item -ItemType Directory -Force -Path $finalSkill | Out-Null
    Write-Utf8File -Path (Join-Path $finalSkill 'sentinel.txt') -Content "concurrent existing skill`r`n"
    $process.WaitForExit()
    $stdout = $process.StandardOutput.ReadToEnd().Trim()
    $stderr = $process.StandardError.ReadToEnd().Trim()
    Assert-True ($process.ExitCode -ne 0) "Concurrent final skill unexpectedly succeeded: $stdout $stderr"
    Assert-True (Test-Path -LiteralPath (Join-Path $finalSkill 'sentinel.txt')) 'Concurrent final skill was lost'
    Assert-True (-not (Test-Path -LiteralPath (Join-Path $finalSkill 'SKILL.md'))) 'Partial incoming skill became discoverable'
    Assert-True (-not (Test-Path -LiteralPath (Join-Path $finalSkill 'bulk.bin'))) 'Staged payload leaked into discoverable skill'
}

Invoke-Test 'failed atomic AGENTS update preserves the original file' {
    $case = Join-Path $runRoot 'agents-update-failure'
    $package = Join-Path $case 'package'
    $codex = Join-Path $case 'codex'
    $agents = Join-Path $case 'agents'
    New-TestPackage -Root $package
    $agentsPath = Join-Path $codex 'AGENTS.md'
    Write-Utf8File -Path $agentsPath -Content "Original protected rules.`r`n"
    $before = Get-FileSha256 $agentsPath
    [IO.File]::SetAttributes($agentsPath, [IO.FileAttributes]::ReadOnly)
    try {
        $result = Invoke-Installer -PackageRoot $package -CodexHome $codex -AgentsHome $agents -Apply
    } finally {
        [IO.File]::SetAttributes($agentsPath, [IO.FileAttributes]::Normal)
    }
    Assert-True ($result.ExitCode -ne 0) 'Read-only AGENTS update unexpectedly succeeded'
    Assert-Equal 'apply_error' $result.Json.status 'Expected atomic AGENTS apply error'
    Assert-Equal $before (Get-FileSha256 $agentsPath) 'Failed AGENTS update changed the original file'
}

Invoke-Test 'reference appearing before atomic publish is preserved' {
    $case = Join-Path $runRoot 'reference-publish-race'
    $package = Join-Path $case 'package'
    $codex = Join-Path $case 'codex'
    $agents = Join-Path $case 'agents'
    New-TestPackage -Root $package -LargeReferenceBytes (32 * 1024 * 1024)
    $process = Start-InstallerProcess -PackageRoot $package -CodexHome $codex -AgentsHome $agents
    $docsRoot = Join-Path $codex 'migrations\2026-11-23\docs'
    $destination = Join-Path $docsRoot 'large.bin'
    $deadline = [DateTime]::UtcNow.AddSeconds(15)
    $temp = $null
    while (-not $temp -and -not $process.HasExited -and [DateTime]::UtcNow -lt $deadline) {
        if (Test-Path -LiteralPath $docsRoot) {
            $temp = Get-ChildItem -LiteralPath $docsRoot -File -Filter '.large.bin.migration-*.tmp' -ErrorAction SilentlyContinue | Select-Object -First 1
        }
        if (-not $temp) { Start-Sleep -Milliseconds 1 }
    }
    Assert-True ($null -ne $temp) 'Installer did not stage the reference beside its destination'
    Write-Utf8File -Path $destination -Content "concurrent reference`r`n"
    $expected = Get-FileSha256 $destination
    $process.WaitForExit()
    $stdout = $process.StandardOutput.ReadToEnd().Trim()
    $stderr = $process.StandardError.ReadToEnd().Trim()
    Assert-Equal 0 $process.ExitCode "$stdout $stderr"
    $json = $stdout | ConvertFrom-Json
    Assert-Equal 'applied_with_conflicts' $json.status 'Expected concurrent reference conflict'
    Assert-Equal $expected (Get-FileSha256 $destination) 'Concurrent reference was overwritten'
    $remainingTemp = Get-ChildItem -LiteralPath $docsRoot -File -Filter '.large.bin.migration-*.tmp' -ErrorAction SilentlyContinue
    Assert-Equal 0 @($remainingTemp).Count 'Owned reference temp was not cleaned after conflict'
}

Invoke-Test 'bad hash exits nonzero before any destination write' {
    $case = Join-Path $runRoot 'bad-hash'
    $package = Join-Path $case 'package'
    $codex = Join-Path $case 'codex'
    $agents = Join-Path $case 'agents'
    New-TestPackage -Root $package -BadHash

    $result = Invoke-Installer -PackageRoot $package -CodexHome $codex -AgentsHome $agents -Apply
    Assert-True ($result.ExitCode -ne 0) 'Bad hash unexpectedly succeeded'
    Assert-Equal 'integrity_error' $result.Json.status 'Expected integrity_error status'
    Assert-True (-not (Test-Path -LiteralPath $codex)) 'Bad hash created CodexHome'
    Assert-True (-not (Test-Path -LiteralPath $agents)) 'Bad hash created AgentsHome'
}

Invoke-Test 'path traversal exits nonzero before any destination write' {
    $case = Join-Path $runRoot 'traversal'
    $package = Join-Path $case 'package'
    $codex = Join-Path $case 'codex'
    $agents = Join-Path $case 'agents'
    New-TestPackage -Root $package -OverridePath 'docs/../../escape.txt'

    $result = Invoke-Installer -PackageRoot $package -CodexHome $codex -AgentsHome $agents -Apply
    Assert-True ($result.ExitCode -ne 0) 'Traversal unexpectedly succeeded'
    Assert-Equal 'integrity_error' $result.Json.status 'Expected integrity_error status'
    Assert-True (-not (Test-Path -LiteralPath $codex)) 'Traversal created CodexHome'
    Assert-True (-not (Test-Path -LiteralPath $agents)) 'Traversal created AgentsHome'
    Assert-True (-not (Test-Path -LiteralPath (Join-Path $case 'escape.txt'))) 'Traversal wrote outside package'
}

$summary = [ordered]@{ status = if ($script:Failed -eq 0) { 'passed' } else { 'failed' }; passed = $script:Passed; failed = $script:Failed; runRoot = $runRoot }
$summary | ConvertTo-Json -Compress
if ($script:Failed -ne 0) { exit 1 }
